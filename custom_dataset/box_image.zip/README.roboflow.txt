
aiffel - v4 box_1
==============================

This dataset was exported via roboflow.ai on May 31, 2022 at 9:13 AM GMT

It includes 636 images.
YOLOX are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 640x640 (Stretch)

The following augmentation was applied to create 3 versions of each source image:
* Random rotation of between -15 and +15 degrees

The following transformations were applied to the bounding boxes of each image:
* 50% probability of horizontal flip
* 50% probability of vertical flip
* Random exposure adjustment of between -25 and +25 percent


